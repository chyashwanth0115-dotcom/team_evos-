-- PostgreSQL + PostGIS. NOTE: the API in this repo runs from in-memory seed data; wire these tables via an ingestor when ready.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TYPE data_origin AS ENUM ('live','forecast','simulated');
CREATE TABLE nodes(id TEXT PRIMARY KEY, type TEXT NOT NULL, name TEXT NOT NULL, geom GEOMETRY(Point,4326) NOT NULL,
  status TEXT DEFAULT 'operational', risk REAL DEFAULT 0 CHECK(risk BETWEEN 0 AND 1), capacity INT, attrs JSONB DEFAULT '{}');
CREATE TABLE edges(src TEXT REFERENCES nodes(id), dst TEXT REFERENCES nodes(id), kind TEXT NOT NULL,
  strength REAL NOT NULL CHECK(strength BETWEEN 0 AND 1), impact TEXT, PRIMARY KEY(src,dst));
CREATE TABLE observations(id BIGSERIAL PRIMARY KEY, node_id TEXT REFERENCES nodes(id), metric TEXT NOT NULL, value DOUBLE PRECISION,
  ts TIMESTAMPTZ NOT NULL, origin data_origin NOT NULL, source TEXT NOT NULL);
CREATE TABLE anomalies(id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ, node_id TEXT, severity TEXT, method TEXT, explanation TEXT, origin data_origin);
CREATE TABLE predictions(id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ, node_id TEXT, horizon_min INT, risk REAL, confidence REAL, model TEXT, trained_on TEXT);
CREATE TABLE alerts(id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ, priority TEXT, problem TEXT, evidence TEXT, consequence TEXT, action TEXT, status TEXT DEFAULT 'open', origin data_origin);
CREATE TABLE scenarios(id SERIAL PRIMARY KEY, name TEXT, params JSONB, results JSONB, created TIMESTAMPTZ DEFAULT now());
CREATE INDEX ON nodes USING GIST(geom); CREATE INDEX ON observations(node_id, ts);
