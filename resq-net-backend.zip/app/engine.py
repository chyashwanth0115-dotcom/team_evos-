"""Graph, cascade, Ripple Score, routing and recommendations (NetworkX)."""
import math, networkx as nx
from dataclasses import dataclass, field
from .seed import *

WEIGHT = {"hospital":3,"substation":3,"road":2,"tower":2,"ambulance":1.5,"team":1.5}
KMH = 25.0

@dataclass
class Scenario:
    rain: float = 4.0
    closed_roads: set = field(default_factory=set)
    down_hospitals: set = field(default_factory=set)
    failed_towers: set = field(default_factory=set)

def hav(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2-la1)/2)**2 + math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 12742*math.asin(math.sqrt(h))

def build():
    D = nx.DiGraph()   # dependency graph
    def node(i, t, name, host=None, **kw):
        if host: lat, lon = AREAS[host][1]+kw.pop("dlat",0), AREAS[host][2]+kw.pop("dlon",0)
        else: lat, lon = kw.pop("lat"), kw.pop("lon")
        D.add_node(i, type=t, name=name, lat=lat, lon=lon, host=host, **kw)
    for k,(n,la,lo,v) in AREAS.items(): node(k,"area",n,lat=la,lon=lo,vuln=v)
    for r,a,b,n in ROADS:
        node(r,"road",n,lat=(AREAS[a][1]+AREAS[b][1])/2,lon=(AREAS[a][2]+AREAS[b][2])/2,ends=(a,b))
        for x in (a,b): D.add_edge(x,r,strength=.9,kind="physical")
    for i,n,h,beds in HOSPITALS:
        node(i,"hospital",n,h,dlat=.004,dlon=-.004,beds=beds)
        for r,a,b,_ in ROADS:
            if h in (a,b): D.add_edge(r,i,strength=.8,kind="access")
    for i,n,h in SUBS:
        node(i,"substation",n,h,dlat=.003,dlon=.003); D.add_edge(h,i,strength=.5,kind="geographic")
    for i,n,h,s in TOWERS:
        node(i,"tower",n,h,dlat=-.003,dlon=.003); D.add_edge(s,i,strength=.7,kind="service")
    for h,s in [("hSakra","sB"),("hManipal","sW"),("hBaptist","sH"),("hVic","sH")]: D.add_edge(s,h,strength=.6,kind="service")
    for i,n,h in AMBULANCES+TEAMS:
        t = "ambulance" if i.startswith("a") else "team"
        node(i,t,n,h,dlat=.002,dlon=-.002)
        for r,a,b,_ in ROADS:
            if h in (a,b): D.add_edge(r,i,strength=.7 if t=="ambulance" else .6,kind="access")
        tw = [x for x in TOWERS if x[2]==h] or [TOWERS[0]]
        D.add_edge(tw[0][0],i,strength=.4,kind="operational")
    return D
G = build()
assert nx.is_directed_acyclic_graph(G)

def depth(area, rain): return max(0.0, rain-15)*G.nodes[area]["vuln"]*1.1   # cm, ASSUMED model

def evaluate(sc: Scenario):
    r = {n: 0.0 for n in G}
    for a in AREAS: r[a] = min(1.0, depth(a, sc.rain)/60)
    for n in sc.closed_roads: r[n] = 1.0
    for n in sc.down_hospitals: r[n] = 1.0
    for n in sc.failed_towers: r[n] = max(r[n], .9)
    for u in nx.topological_sort(G):      # exact on a DAG
        for _, v, d in G.out_edges(u, data=True): r[v] = max(r[v], r[u]*d["strength"])
    ids = [n for n in G if G.nodes[n]["type"]!="area"]
    score = 100*sum(WEIGHT[G.nodes[n]["type"]]*r[n] for n in ids)/sum(WEIGHT[G.nodes[n]["type"]] for n in ids)
    closed = [x[0] for x in ROADS if x[0] in sc.closed_roads or r[x[0]]>=.6]
    return {"risk": {k: round(v,3) for k,v in r.items()}, "ripple_score": round(score,1), "closed_roads": closed}

def road_graph(ev, sc):
    R = nx.Graph()
    for rid,a,b,_ in ROADS:
        if rid in ev["closed_roads"]: continue
        km = hav((G.nodes[a]["lat"],G.nodes[a]["lon"]),(G.nodes[b]["lat"],G.nodes[b]["lon"]))
        R.add_edge(a,b,w=km/KMH*60*(1+2*max(ev["risk"][a],ev["risk"][b])))
    for hid,_n,host,_b in HOSPITALS:
        if hid not in sc.down_hospitals: R.add_edge(host,hid,w=.3)
    return R

def best_route(ev, sc, area):
    R = road_graph(ev, sc)
    if area not in R: return None
    best = None
    for h,*_ in HOSPITALS:
        if h in R:
            try:
                L, p = nx.single_source_dijkstra(R, area, h, weight="w")
                if best is None or L < best[0]: best = (L, p)
            except nx.NetworkXNoPath: pass
    return None if best is None else {"minutes": round(best[0],1), "path": best[1]}

def response_eta(ev, sc, extra_host=None):
    R = road_graph(ev, sc); hosts = [a[2] for a in AMBULANCES] + ([extra_host] if extra_host else [])
    tot = n = miss = 0
    for a in AREAS:
        try:
            to = min(nx.dijkstra_path_length(R,h,a,weight="w") for h in hosts if h in R and a in R and nx.has_path(R,h,a))
            hs = best_route(ev, sc, a); tot += to+hs["minutes"]; n += 1
        except (ValueError, nx.NetworkXNoPath, TypeError, KeyError): miss += 1
    return {"avg_minutes": round(tot/n,1) if n else None, "unreachable_areas": miss}

def cascade(ev, source):
    """Ranked downstream impacts with the strongest cause-effect path to each node."""
    sub = G.subgraph(nx.descendants(G,source)|{source})
    best = {source:(ev["risk"][source],[source])}
    for u in nx.topological_sort(sub):
        for _,v,d in sub.out_edges(u,data=True):
            val = best[u][0]*d["strength"]
            if v not in best or val > best[v][0]: best[v]=(val, best[u][1]+[v])
    out = [{"node":k,"name":G.nodes[k]["name"],"risk":round(v[0],3),"path":[G.nodes[p]["name"] for p in v[1]]} for k,v in best.items() if k!=source]
    return sorted(out, key=lambda x:-x["risk"])

def criticality():
    """Weighted descendant count = how much of the system depends on a node (structural, scenario-independent)."""
    return sorted(({"node":n,"name":G.nodes[n]["name"],"type":G.nodes[n]["type"],
        "dependents":len(nx.descendants(G,n)),
        "weighted":round(sum(WEIGHT.get(G.nodes[d]["type"],0) for d in nx.descendants(G,n)),1)} for n in G), key=lambda x:-x["weighted"])

def stage_point(ev, sc):
    worst = max(AREAS, key=lambda a: ev["risk"][a])
    if ev["risk"][worst] < .25: return None
    R = road_graph(ev, sc)
    if worst not in R: return None
    d = nx.single_source_dijkstra_path_length(R, worst, weight="w")
    c = [a for a in AREAS if ev["risk"][a] < .3 and a in d]
    return min(c, key=d.get) if c else None

def recommendations(ev, sc):
    out, r = [], ev["risk"]
    stage = stage_point(ev, sc)
    worst = max(AREAS, key=lambda a: r[a])
    for a in sorted(AREAS, key=lambda a:-r[a])[:3]:
        if r[a] < .4: continue
        closed = [x[3] for x in ROADS if a in x[1:3] and x[0] in ev["closed_roads"]]
        hit = [c["name"] for c in cascade(ev,a) if G.nodes[c["node"]]["type"] in ("hospital","ambulance") and c["risk"]>=.4]
        ok = [h[1] for h in HOSPITALS if h[0] not in sc.down_hospitals and r[h[0]]<.5]
        out.append({"priority":"Critical" if r[a]>=.75 else "High","problem":f"{AREAS[a][0]} risk {r[a]:.0%}",
          "evidence":f"rain {sc.rain} mm/h (simulated), est. depth {depth(a,sc.rain):.0f} cm, vulnerability {AREAS[a][3]}; closed: {closed or 'none'}",
          "consequence":f"reduced access for {', '.join(hit) or 'no hospital/ambulance yet'}",
          "action":f"use open roads only; viable hospitals: {', '.join(ok) or 'none'}"+(f"; stage an ambulance/team at {AREAS[stage][0]}" if stage and a==worst else "")})
    return out, stage
