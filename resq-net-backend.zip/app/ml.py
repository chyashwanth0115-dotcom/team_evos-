"""ML layer. IMPORTANT: no real flood/incident data is available in this repo.
Models are trained on SYNTHETIC data generated from the same assumed physics as the engine, so any score
printed by train() only shows the pipeline runs. It says nothing about real-world accuracy."""
import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
FEATS = ["rain","rain_delta","vuln"]
_state = {}

def _synthetic(n=4000, seed=0):
    g = np.random.default_rng(seed)
    rain = g.uniform(0,110,n); delta = g.normal(3,5,n); vuln = g.uniform(.4,1,n)
    risk = np.clip(np.maximum(0,rain-15)*vuln*1.1/60 + g.normal(0,.03,n), 0, 1)
    return np.c_[rain,delta,vuln], risk

def train():
    X, y = _synthetic(); Xt, Xv, yt, yv = train_test_split(X,y,random_state=0)
    rf = RandomForestRegressor(200, random_state=0).fit(Xt,yt)
    iso = IsolationForest(contamination=.02, random_state=0).fit(X[:,:2])
    _state.update(rf=rf, iso=iso)
    return {"data":"SYNTHETIC ONLY","rf_holdout_mae_on_synthetic":round(float(mean_absolute_error(yv,rf.predict(Xv))),4),
            "note":"Not evidence of real-world accuracy.","feature_importance":dict(zip(FEATS,[round(float(x),3) for x in rf.feature_importances_]))}

def predict_risk(rain, delta, vuln, horizon_steps=3):
    """Extrapolate rainfall linearly, then score with the RF. Confidence = 1 - spread across trees (heuristic)."""
    if "rf" not in _state: train()
    future = float(np.clip(rain + horizon_steps*delta, 0, 120)); x = np.array([[future,delta,vuln]])
    preds = np.array([t.predict(x)[0] for t in _state["rf"].estimators_])
    return {"horizon_minutes":5*horizon_steps,"predicted_risk":round(float(preds.mean()),3),
            "confidence":round(float(max(0,1-2*preds.std())),2),"label":"forecast from synthetic-trained model",
            "factors":dict(zip(FEATS,[round(float(v),3) for v in _state["rf"].feature_importances_]))}

def anomalies(rain_series, depth_bellandur):
    """Rain-rate threshold + z-score + Isolation Forest on (rain, delta)."""
    if "iso" not in _state: train()
    out, d = [], np.diff(rain_series)
    if len(d)==0: return out
    last = float(d[-1])
    if last >= 15: out.append({"severity":"critical","method":"threshold","why":f"rain rose {last:.0f} mm/h in 5 min (limit 15)"})
    elif last >= 10: out.append({"severity":"high","method":"threshold","why":f"rain rose {last:.0f} mm/h in 5 min (limit 10)"})
    if len(d)>=3:
        z=(last-d[:-1].mean())/max(1,d[:-1].std())
        if z>2: out.append({"severity":"warning","method":"z-score","why":f"{z:.1f} sd above recent trend"})
    if _state["iso"].predict([[rain_series[-1],last]])[0]==-1:
        out.append({"severity":"warning","method":"isolation_forest","why":"(rain, rain change) pair is unusual vs. synthetic baseline"})
    if depth_bellandur>=40: out.append({"severity":"high","method":"threshold","why":f"Bellandur depth {depth_bellandur:.0f} cm"})
    return out
