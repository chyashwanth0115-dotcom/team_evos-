import asyncio
from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from . import engine as E, ml
from .seed import AREAS

app = FastAPI(title="RESQ-NET API", description="All data is SIMULATED unless an ingestor says otherwise.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
RAIN_SERIES = [4,10,24,42,55,64,70,72]   # simulated demo storm, 4:00-4:35 PM

class Body(BaseModel):
    rain: float = Field(4, ge=0, le=150)
    closed_roads: list[str] = []
    down_hospitals: list[str] = []
    failed_towers: list[str] = []
    step: int = Field(0, ge=0, le=7, description="index into the simulated storm series")
    def sc(self): return E.Scenario(self.rain, set(self.closed_roads), set(self.down_hospitals), set(self.failed_towers))

@app.on_event("startup")
def _train(): app.state.train_report = ml.train()

@app.get("/api/meta")
def meta(): return {"data_mode":"SIMULATION","train_report":app.state.train_report}
@app.get("/api/graph")
def graph():
    return {"nodes":[{"id":n,**d} for n,d in E.G.nodes(data=True)],"edges":[{"source":u,"target":v,**d} for u,v,d in E.G.edges(data=True)]}
@app.get("/api/criticality")
def crit(): return E.criticality()
@app.post("/api/state")
def state(b: Body):
    sc=b.sc(); ev=E.evaluate(sc); return {**ev,"depth_cm":{a:round(E.depth(a,sc.rain),1) for a in AREAS},"data_mode":"SIMULATION"}
@app.post("/api/cascade/{node}")
def cascade(node: str, b: Body):
    if node not in E.G: raise HTTPException(404,"unknown node")
    return E.cascade(E.evaluate(b.sc()), node)
@app.post("/api/anomalies")
def anomalies(b: Body):
    return ml.anomalies(RAIN_SERIES[:b.step]+[b.rain], E.depth("bellandur", b.rain))
@app.post("/api/predict")
def predict(b: Body):
    prev = RAIN_SERIES[b.step-1] if b.step else b.rain
    return {a: ml.predict_risk(b.rain, b.rain-prev, AREAS[a][3]) for a in AREAS}
@app.post("/api/route/{area}")
def route(area: str, b: Body):
    sc=b.sc(); r=E.best_route(E.evaluate(sc), sc, area)
    if r is None: raise HTTPException(409,"no accessible hospital from this area")
    return r
@app.post("/api/compare")
def compare(b: Body):
    base=E.Scenario(); cur=b.sc(); ev0,ev1=E.evaluate(base),E.evaluate(cur)
    recs,stage=E.recommendations(ev1,cur)
    return {"normal":{**ev0,"response":E.response_eta(ev0,base)},"simulated":{**ev1,"response":E.response_eta(ev1,cur)},
            "recommended":{"stage_at":stage,"response":E.response_eta(ev1,cur,stage)},"recommendations":recs}
@app.post("/api/recommendations")
def recs(b: Body):
    sc=b.sc(); return E.recommendations(E.evaluate(sc),sc)[0]

@app.websocket("/ws/replay")
async def replay(ws: WebSocket):
    """Streams the SIMULATED storm one step per second."""
    await ws.accept()
    for i,r in enumerate(RAIN_SERIES):
        await ws.send_json({"mode":"SIMULATION","step":i,"rain":r,**E.evaluate(E.Scenario(rain=r))}); await asyncio.sleep(1)
    await ws.close()
