"""Seed infrastructure for the Bengaluru east-corridor demo.
Area/hospital coordinates are APPROXIMATE public locations (verify before real use).
Substations, towers, ambulances, teams and all vulnerability / strength values are SIMULATED assumptions."""
AREAS = {  # id: (name, lat, lon, drainage_vulnerability 0-1)
 "bellandur": ("Bellandur", 12.9304, 77.6784, 1.0),
 "marathahalli": ("Marathahalli", 12.9569, 77.7011, 0.8),
 "whitefield": ("Whitefield", 12.9698, 77.7500, 0.5),
 "krpuram": ("KR Puram", 13.0075, 77.6955, 0.7),
 "hebbal": ("Hebbal", 13.0358, 77.5970, 0.6),
 "mgroad": ("MG Road", 12.9756, 77.6068, 0.45)}
ROADS = [("rd1","bellandur","marathahalli","ORR Bellandur-Marathahalli"),("rd2","marathahalli","whitefield","Marathahalli-Whitefield"),
 ("rd3","marathahalli","krpuram","Marathahalli-KR Puram"),("rd4","krpuram","hebbal","KR Puram-Hebbal"),
 ("rd5","mgroad","marathahalli","MG Road-Marathahalli"),("rd6","mgroad","hebbal","MG Road-Hebbal"),("rd7","bellandur","mgroad","Bellandur-MG Road")]
HOSPITALS = [("hSakra","Sakra World Hospital","bellandur",60),("hManipal","Manipal Hospital","marathahalli",90),
 ("hBaptist","Baptist Hospital","hebbal",70),("hVic","Victoria Hospital","mgroad",120)]  # beds are SIMULATED
SUBS = [("sB","Substation Bellandur","bellandur"),("sW","Substation Whitefield","whitefield"),("sH","Substation Hebbal","hebbal")]
TOWERS = [("tM","Tower Marathahalli","marathahalli","sB"),("tW","Tower Whitefield","whitefield","sW"),("tH","Tower Hebbal","hebbal","sH")]
AMBULANCES = [("a1","Ambulance 1","bellandur"),("a2","Ambulance 2","marathahalli"),("a3","Ambulance 3","krpuram"),("a4","Ambulance 4","mgroad")]
TEAMS = [("t1","Rescue team 1","hebbal"),("t2","Rescue team 2","mgroad"),("t3","Rescue team 3","whitefield")]
