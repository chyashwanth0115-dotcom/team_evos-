# RESQ-NET backend (prototype)
Cascading-impact engine for the Bengaluru east corridor. **All data is simulated; models are trained on synthetic data only.**

## Run
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    uvicorn app.main:app --reload      # docs at http://localhost:8000/docs

## Try the demo
    curl -X POST localhost:8000/api/compare -H 'content-type: application/json' \
      -d '{"rain":72,"step":7,"closed_roads":["rd1","rd7"]}'
Other endpoints: /api/graph, /api/criticality, /api/state, /api/cascade/{node}, /api/anomalies, /api/predict, /api/route/{area}, /api/recommendations, ws://localhost:8000/ws/replay.

## Modules
- app/seed.py – infrastructure and assumptions
- app/engine.py – NetworkX dependency DAG, risk propagation, Ripple Score, routing, recommendations
- app/ml.py – Isolation Forest, z-score, thresholds, Random Forest risk model (synthetic training)
- db/schema.sql – PostGIS schema (not yet connected)

## Ripple Score
100 x sum(w_i r_i)/sum(w_i) over non-area nodes; w: hospital 3, substation 3, road 2, tower 2, ambulance/team 1.5. r_i is propagated risk, r(dst)=max(r(dst), r(src) x strength). **Not calibrated** – needs historical incident data.

## Not done yet
DB wiring/ingestion adapters, real weather/traffic APIs, XGBoost and GNN, React front end on these APIs (see the standalone demo page), alert persistence, historical analytics.
